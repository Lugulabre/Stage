This example dataset consists of 20000 gametes per source population, each gamete comprising 500 biallelic markers.
The dataset was generated using the same source populations and methodology as described in Fortes-Lima et al. (ref MER).
The datasets used in Fortes-Lima et al. (ref MER) are too large to be deposited in this github, but are available upon request. Please contact Paul Verdu (verdu@mnhn.fr) and Romain Laurent (laurent@mnhn.fr).

